#include <string>

using namespace std;

struct Lista {
  bool sublista;
  string valorString;
  Lista* valorSublista;
  Lista* proximo;
};

Lista* geraLista() {
  Lista *p0, *p1, *p2, *p3, *p4, *p5, *p6, *p7;

  p0 = new Lista;
  p0->sublista = false;
  p0->valorString = "meme";
  p0->valorSublista = nullptr;

  p1 = new Lista;
  p1->sublista = false;
  p1->valorString = "arroz";
  p1->valorSublista = nullptr;

  p2 = new Lista;
  p2->sublista = false;
  p2->valorString = "1";
  p2->valorSublista = nullptr;

  p3 = new Lista;
  p3->sublista = false;
  p3->valorString = "2";
  p3->valorSublista = nullptr;

  p4 = new Lista;
  p4->sublista = false;
  p4->valorString = "5";
  p4->valorSublista = nullptr;


  p7 = new Lista;
  p7->sublista = false;
  p7->valorString = "matheus";
  p7->valorSublista = nullptr;

  p7->proximo = nullptr;

  (->proximo = p7;

  p4->proximo = (;

  p3->proximo = p4;

  p2->proximo = p3;

  p1->proximo = p2;

  p0->proximo = p1;

  return p0;
}
